You may use the .wrd file for anything you wish.

Run the installer (WRDEDIT_installer.exe) and agree to the license and answer all the questions.

Then click on the application and use it for editing .wrd files.